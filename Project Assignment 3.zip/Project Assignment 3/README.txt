Project Assignment 3 Submission for Software-Hardware Codesign
Spring 2016, FAU, Dr. Shankar

Authors: Alex Achenbach and Dimitri DeBarnes

----------------------------------------------------

In this folder you will find the following:

- StressManagementv13.1 Release Version (.zip folder):
	This is the source code used for the final version of our Android application, from the live demonstration
	on 4/29. All required assets and other resources needed to build the application are included in this
	folder.

- Healthcare App Final Presentation (.ppt file):
	A copy of the presentation that was used during the 4/29 demonstration.

- Assets (.zip folder):
	This is a folder containing all of the graphics, backgrounds, and other assets used within the application.
	Note that the application folder referenced above already contains these assets. However, they have been
	included here as a standalone folder for your convenience.

- Final Report (.pdf):
	This is the final report written in an academic format describing the work that went into this project,
	and a discussion of the background, methods, and results. It also includes some sources for the github
	repository and other relevant links.

- Tutorial (.pdf):
	A brief tutorial describing the features of the application and how to use it.
	

Please note that there is NO marketing video included in this folder or our project, due to the fact that our group does
not possess an arts student.