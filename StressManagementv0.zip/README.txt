Dimitri DeBarnes

Group 1

03/27/16

Stress Management App v0
*******************************
Change Log:

-Base layout built upon from the Sudoku v4 layout

-Includes the 7 questions we are using from Thisha's research

-Buttons currently function to loop through survey
	Plan to add a back button

-Next update to include a stress level counter to track the responses of user
	Counter will be used to categorize user's stress level and corresponding
	advisory notice to the user