package org.example.stress;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

/**
 * Created by Alex on 4/28/2016.
 */
public class SelfCarePlan extends Activity implements OnClickListener {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selfcareplan);

        final View stressJournalButton = findViewById(R.id.button_stressjournal); //link to the layout file
        stressJournalButton.setOnClickListener(this); //<--enable the button

        final View supportSystemButton = findViewById(R.id.support_system_button); //link to the layout file
        supportSystemButton.setOnClickListener(this); //<--enable the button

        final View exerciseButton = findViewById(R.id.exercise_plan_button); //link to the layout file
        exerciseButton.setOnClickListener(this); //<--enable the button

        final View relaxationButton = findViewById(R.id.relaxation_button); //link to the layout file
        relaxationButton.setOnClickListener(this); //<--enable the button

        final View recreationButton = findViewById(R.id.recreation_button); //link to the layout file
        recreationButton.setOnClickListener(this); //<--enable the button

        final View graphButton = findViewById(R.id.show_graph_button); //link to the layout file
        graphButton.setOnClickListener(this); //<--enable the button

    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_stressjournal:
                Intent i1 = new Intent(this, Journal.class); //intent object is android code, passes control between classes
                startActivity(i1); //Each activity must be activated by the intent object
                finish();
                break;

            case R.id.support_system_button:
                Intent i2 = new Intent(this, SupportSystem.class); //intent object is android code, passes control between classes
                startActivity(i2); //Each activity must be activated by the intent object
                break;

            case R.id.exercise_plan_button:
                Intent i3 = new Intent(this, ExercisePlan.class); //intent object is android code, passes control between classes
                startActivity(i3); //Each activity must be activated by the intent object
                break;

            case R.id.relaxation_button:
                Intent i4 = new Intent(this, Relaxation.class); //intent object is android code, passes control between classes
                startActivity(i4); //Each activity must be activated by the intent object
                break;

            case R.id.recreation_button:
                Intent i5 = new Intent(this, Recreational.class); //intent object is android code, passes control between classes
                startActivity(i5); //Each activity must be activated by the intent object
                break;

            case R.id.show_graph_button:
                Intent i6 = new Intent(this, Graph.class); //intent object is android code, passes control between classes
                startActivity(i6); //Each activity must be activated by the intent object
                break;


        }
    }
}


