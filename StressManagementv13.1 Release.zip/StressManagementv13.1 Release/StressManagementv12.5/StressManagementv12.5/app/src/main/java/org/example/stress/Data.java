package org.example.stress;

import android.app.Application;

/**
 * Created by Alex on 3/29/2016.
 */
public class Data extends Application {

    private int entryNumber = 0;
    private String date = "";
    private int stressLevel = 0;
    private String sources = "";
    private String symptoms = "";
    private String notes = "";
    private boolean isNewEntryFlag = false;

    public int getEntryNumber() { return entryNumber; }
    public void setEntryNumber(int foo) { entryNumber = foo; }

    public String getDate() { return date; }
    public void setDate(String foo) { date = foo; }

    public int getStressLevel() { return stressLevel; }
    public void setStressLevel(int foo) { stressLevel = foo; }

    public String getSources() { return sources; }
    public void setSources(String foo) { sources = foo; }

    public String getSymptoms() { return symptoms; }
    public void setSymptoms(String foo) { symptoms = foo; }

    public String getNotes()
    {
        return notes;
    }
    public void setNotes(String foo)
    {
        notes = foo;
    }

    public void toggleNewEntryFlag() {
        if(isNewEntryFlag == true)
        {
            isNewEntryFlag = false;
        }
        else
        {
            isNewEntryFlag = true;
        }
    }

    public boolean isNewEntry() {
        return isNewEntryFlag;
    }
}
