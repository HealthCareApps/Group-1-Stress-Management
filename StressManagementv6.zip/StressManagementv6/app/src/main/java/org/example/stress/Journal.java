package org.example.stress;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Alex on 4/24/2016.
 */
public class Journal extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainmenu);

        //TextView edText1 = (TextView) findViewById(R.id.textV_entrynumber);
        //TextView edText2 = (TextView) findViewById(R.id.textV_date);
        //TextView edText3 = (TextView) findViewById(R.id.textV_stress);
        //TextView edText4 = (TextView) findViewById(R.id.textV_sources);
        //TextView edText5 = (TextView) findViewById(R.id.textV_symptoms);
        //TextView edText6 = (TextView) findViewById(R.id.textV_notes);





    }
}
