
package org.example.stress;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;

public class Question6 extends Activity implements OnClickListener {
   private static final String TAG = "Question6";

   /** Called when the activity is first created. */
   @Override
   public void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.question6);
      Bundle Question = getIntent().getExtras();


      // Set up click listeners for all the buttons
      View continueButton = findViewById(R.id.na_button); //link to the layout file
      continueButton.setOnClickListener(this); //<--enable the button
      View newButton = findViewById(R.id.sd_button);
      newButton.setOnClickListener(this);
      View aboutButton = findViewById(R.id.cd_button);
      aboutButton.setOnClickListener(this);
      View exitButton = findViewById(R.id.hd_button);
      exitButton.setOnClickListener(this);
   }

   @Override
   protected void onResume() {
      super.onResume();
      //Question4.play(this, R.raw.main);
   }

   @Override
   protected void onPause() {
      super.onPause();
      //Question4.stop(this);
   }

   public void onClick(View v) {
      switch (v.getId()) {
         case R.id.na_button:
            Intent i1 = new Intent(this, Question7.class); //intent object is android code, passes control between classes
            startActivity(i1); //Each activity must be activated by the intent object
            break;

         case R.id.sd_button:
            Intent i2 = new Intent(this, Question7.class); //intent object is android code, passes control between classes
            startActivity(i2); //Each activity must be activated by the intent object
            break;

         case R.id.cd_button:
            Intent i3 = new Intent(this, Question7.class); //intent object is android code, passes control between classes
            startActivity(i3); //Each activity must be activated by the intent object
            break;

         case R.id.hd_button:
            Intent i4 = new Intent(this, Question7.class); //intent object is android code, passes control between classes
            startActivity(i4); //Each activity must be activated by the intent object
            break;
      }
   }

   @Override
   public boolean onCreateOptionsMenu(Menu menu) {
      super.onCreateOptionsMenu(menu);
      MenuInflater inflater = getMenuInflater();
      inflater.inflate(R.menu.menu, menu);
      return true;
   }

   @Override
   public boolean onOptionsItemSelected(MenuItem item) {
      switch (item.getItemId()) {
         case R.id.settings:
            //startActivity(new Intent(this, Question3.class));
            return true;
         // More items go here (if any) ...
      }
      return false;
   }

   /** Ask the user what difficulty level they want */
   /*private void openNewGameDialog() {
      new AlertDialog.Builder(this)
           .setTitle(R.string.new_game_title)
           .setItems(R.array.difficulty,
            new DialogInterface.OnClickListener() {
               public void onClick(DialogInterface dialoginterface,
                     int i) {
                  startGame(i);
               }
            })
           .show();
   }

   /** Start a new game with the given difficulty level
   private void startGame(int i) {
      Log.d(TAG, "clicked on " + i);
      Intent intent = new Intent(this, Question6.class);
      intent.putExtra(Question6.KEY_DIFFICULTY, i);
      startActivity(intent);
   }*/
}