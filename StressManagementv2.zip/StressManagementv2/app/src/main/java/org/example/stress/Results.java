package org.example.stress;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class Results extends Activity implements OnClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.results);

        View continueButton = findViewById(R.id.return_button); //link to the layout file
        continueButton.setOnClickListener(this); //<--enable the button
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.return_button:
                Intent i1 = new Intent(this, MainMenu.class); //intent object is android code, passes control between classes
                startActivity(i1); //Each activity must be activated by the intent object
                break;
        }
    }
}