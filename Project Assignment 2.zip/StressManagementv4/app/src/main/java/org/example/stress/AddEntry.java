package org.example.stress;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class AddEntry extends Activity implements OnClickListener {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addentry);

        View continueButton = findViewById(R.id.sources_button); //link to the layout file
        continueButton.setOnClickListener(this); //<--enable the button
        View newButton = findViewById(R.id.symptoms_button);
        newButton.setOnClickListener(this);
        View aboutButton = findViewById(R.id.notes_button);
        aboutButton.setOnClickListener(this);
        View submitButton = findViewById(R.id.submit_button);
        submitButton.setOnClickListener(this);


    }

    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.sources_button:
                Intent i1 = new Intent(this, MainMenu.class); //intent object is android code, passes control between classes
                startActivity(i1); //Each activity must be activated by the intent object
                finish();
                break;

            case R.id.symptoms_button:
                Intent i2 = new Intent(this, MainMenu.class); //intent object is android code, passes control between classes
                startActivity(i2); //Each activity must be activated by the intent object
                finish();
                break;

            case R.id.notes_button:

                Intent i3 = new Intent(this, MainMenu.class); //intent object is android code, passes control between classes
                startActivity(i3); //Each activity must be activated by the intent object
                finish();
                break;

            case R.id.submit_button:
                Intent i4 = new Intent(this, MainMenu.class); //intent object is android code, passes control between classes
                startActivity(i4); //Each activity must be activated by the intent object
                finish();
                break;

        }
    }
}