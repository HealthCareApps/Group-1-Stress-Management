package org.example.stress;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class Results extends Activity implements OnClickListener {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.results);

        View continueButton = findViewById(R.id.return_button); //link to the layout file
        continueButton.setOnClickListener(this); //<--enable the button

        int temp = ((Data) this.getApplication()).getStressLevel();
        temp = temp * 2;

        TextView myTextView = (TextView) findViewById(R.id.score);
        myTextView.setText("Your score is " + temp);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.return_button:
                ((Data)this.getApplication()).setStressLevel(0);
                Intent i1 = new Intent(this, MainMenu.class); //intent object is android code, passes control between classes
                startActivity(i1); //Each activity must be activated by the intent object
                finish();
                break;
        }
    }
}