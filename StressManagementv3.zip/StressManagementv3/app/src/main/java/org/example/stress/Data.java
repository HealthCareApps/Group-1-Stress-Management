package org.example.stress;

import android.app.Application;

/**
 * Created by Alex on 3/29/2016.
 */
public class Data extends Application {

    private int stressLevel = 0;

    public int getStressLevel()
    {
        return stressLevel;
    }

    public void setStressLevel(int foo)
    {
        stressLevel = foo;
    }
}
