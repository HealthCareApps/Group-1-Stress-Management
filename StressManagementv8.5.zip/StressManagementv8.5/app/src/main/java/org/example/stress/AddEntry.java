package org.example.stress;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Date;


public class AddEntry extends Activity implements OnClickListener {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addentry);

        View submitButton = findViewById(R.id.submit_button);
        submitButton.setOnClickListener(this);



    }

    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.submit_button:

                //TODO: this is where the entry should be converted to a database entry!!!!!
                DBHandler dbHandler = new DBHandler(this, null, null, 1);

                String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date()); //set date to todays date

                int entry_num = dbHandler.findMaxID() + 1;

                ((Data)this.getApplication()).setEntryNumber(entry_num); //increment global count for data entry number

                //stress level is already set from Results activity

                EditText edText1 = (EditText) findViewById(R.id.text_source);
                EditText edText2 = (EditText) findViewById(R.id.text_symptoms);
                EditText edText3 = (EditText) findViewById(R.id.text_notes);

                String temp_sources = edText1.getText().toString();
                String temp_symptoms = edText2.getText().toString();
                String temp_notes = edText3.getText().toString();

                ((Data)this.getApplication()).setEntryNumber(entry_num);
                ((Data)this.getApplication()).setDate(date);
                //((Data)this.getApplication()).setStressLevel(0);
                ((Data)this.getApplication()).setSources(temp_sources);
                ((Data)this.getApplication()).setSymptoms(temp_symptoms);
                ((Data)this.getApplication()).setNotes(temp_notes);


                dbHandler.addEntry((Data) this.getApplication());

                ((Data)this.getApplication()).setStressLevel(0); //now that database entry is added, reset stress level in preparation for next test

                Intent i = new Intent(this, Journal.class); //intent object is android code, passes control between classes
                startActivity(i); //Each activity must be activated by the intent object
                finish();
                break;

        }
    }
}