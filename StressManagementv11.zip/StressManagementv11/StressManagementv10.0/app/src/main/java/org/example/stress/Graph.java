package org.example.stress;

import android.os.Bundle;
import android.app.Activity;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.Vector;

/**
 * Created by Alex Achenbach on 4/28/2016.
 */


public class Graph extends Activity {

    DBAdapter myDb;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.graph);
        openDB();
        drawGraph();
    }

    public void drawGraph(){
        GraphView graph = (GraphView) findViewById(R.id.graph);

        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(new DataPoint[] {
                //empty  to start with
                new DataPoint(0, 1),
                new DataPoint(1, 5),
                new DataPoint(2, 3),
                new DataPoint(3, 2),
                new DataPoint(4, 6)
        });
/*
        Vector<Integer> v_entryNumber=new Vector<Integer>(10,1){};
        Vector<Integer> v_stressLevel=new Vector<Integer>(10,1){};
        int i = v_entryNumber.get(5);

        for (int j = 0; j < 10; j++)
        {
            DataPoint data = new DataPoint(v_entryNumber.get(i), v_stressLevel.get(i));
            series.appendData(data, true, 10);
        }
*/

        graph.addSeries(series);

    }

    protected void onDestroy() {
        super.onDestroy();
        closeDB();
    }

    private void openDB() {
        myDb = new DBAdapter(this);
        myDb.open();
    }
    private void closeDB() {
        myDb.close();
    }

}


