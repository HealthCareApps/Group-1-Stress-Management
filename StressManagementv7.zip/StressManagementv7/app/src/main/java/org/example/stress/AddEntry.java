package org.example.stress;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;


public class AddEntry extends Activity implements OnClickListener {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addentry);


        //View continueButton = findViewById(R.id.sources_button); //link to the layout file
        //continueButton.setOnClickListener(this);


        //View newButton = findViewById(R.id.symptoms_button);
       // newButton.setOnClickListener(this);


        //View aboutButton = findViewById(R.id.notes_button);
       // aboutButton.setOnClickListener(this);


        View submitButton = findViewById(R.id.submit_button);
        submitButton.setOnClickListener(this);



    }

    public void onClick(View v) {
        switch (v.getId()) {
/*
            case R.id.sources_button:
                Intent i1 = new Intent(this, MainMenu.class); //intent object is android code, passes control between classes
                startActivity(i1); //Each activity must be activated by the intent object
                finish();
                break;

            case R.id.symptoms_button:
                Intent i2 = new Intent(this, MainMenu.class); //intent object is android code, passes control between classes
                startActivity(i2); //Each activity must be activated by the intent object
                finish();
                break;

            case R.id.notes_button:

                Intent i3 = new Intent(this, MainMenu.class); //intent object is android code, passes control between classes
                startActivity(i3); //Each activity must be activated by the intent object
                finish();
                break;
*/
            case R.id.submit_button:

                //TODO: this is where the entry should be converted to a database entry!!!!!

                EditText edText1 = (EditText) findViewById(R.id.text_source);
                EditText edText2 = (EditText) findViewById(R.id.text_symptoms);
                EditText edText3 = (EditText) findViewById(R.id.text_notes);

                String temp_sources = edText1.getText().toString();
                String temp_symptoms = edText2.getText().toString();
                String temp_notes = edText3.getText().toString();

                ((Data)this.getApplication()).setEntryNumber(1);
                ((Data)this.getApplication()).setDate("4/25/2016");
                ((Data)this.getApplication()).setStressLevel(15);
                ((Data)this.getApplication()).setSources(temp_sources);
                ((Data)this.getApplication()).setSymptoms(temp_symptoms);
                ((Data)this.getApplication()).setNotes(temp_notes);

                DBHandler dbHandler = new DBHandler(this, null, null, 1);

                dbHandler.addEntry((Data) this.getApplication());


                Intent i = new Intent(this, Journal.class); //intent object is android code, passes control between classes
                startActivity(i); //Each activity must be activated by the intent object
                finish();
                break;

        }
    }
}