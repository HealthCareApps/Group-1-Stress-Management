package org.example.stress;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Alex on 4/24/2016.
 */
public class Journal extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.journal);



        //int temp1 = ((Data) this.getApplication()).getEntryNumber();
        //String temp2 = ((Data) this.getApplication()).getDate();
        //int temp3 = ((Data) this.getApplication()).getStressLevel();
        //String temp4 = ((Data) this.getApplication()).getSources();
        //String temp5 = ((Data) this.getApplication()).getSymptoms();
        //String temp6 = ((Data) this.getApplication()).getNotes();

        //TODO: This activity should be invoking a database entry instead of directly referencing the variables

        DBHandler dbHandler = new DBHandler(this, null, null, 1);
        Data data = dbHandler.findEntry(1);


        TextView Text1 = (TextView) findViewById(R.id.textV_id);
        Text1.setText(String.valueOf(data.getEntryNumber()));

        TextView Text2 = (TextView) findViewById(R.id.textV_date);
        Text2.setText(String.valueOf(data.getDate()));

        TextView Text3 = (TextView) findViewById(R.id.textV_stress);
        Text3.setText(String.valueOf(data.getStressLevel()));

        TextView Text4 = (TextView) findViewById(R.id.textV_sources);
        Text4.setText(String.valueOf(data.getSources()));

        TextView Text5 = (TextView) findViewById(R.id.textV_symptoms);
        Text5.setText(String.valueOf(data.getSymptoms()));

        TextView Text6 = (TextView) findViewById(R.id.textV_notes);
        Text6.setText(String.valueOf(data.getNotes()));





    }
}
