package org.example.stress;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

/**
 * Created by Alex on 3/28/2016.
 */
public class MainMenu extends Activity implements OnClickListener {



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainmenu);
        Bundle Question = getIntent().getExtras();

        // Set up click listeners for all the buttons
        View continueButton = findViewById(R.id.new_button); //link to the layout file
        continueButton.setOnClickListener(this); //<--enable the button
        View newButton = findViewById(R.id.log_button);
        newButton.setOnClickListener(this);
        View aboutButton = findViewById(R.id.about_button);
        aboutButton.setOnClickListener(this);
        View exitButton = findViewById(R.id.plan_button);
        exitButton.setOnClickListener(this);

        Data data = ((Data)getApplicationContext());

    }



    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.new_button:
                ((Data)this.getApplication()).setStressLevel(0);
                Intent i1 = new Intent(this, Question1.class); //intent object is android code, passes control between classes
                startActivity(i1); //Each activity must be activated by the intent object
                break;

            case R.id.log_button:
                Intent i2 = new Intent(this, Journal.class); //intent object is android code, passes control between classes
                startActivity(i2); //Each activity must be activated by the intent object
                break;

            case R.id.about_button:
                Intent i3 = new Intent(this, About.class); //intent object is android code, passes control between classes
                startActivity(i3); //Each activity must be activated by the intent object
                break;

            case R.id.plan_button:

                break;
        }
    }
}
