package org.example.stress;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;

public class DBHandler extends SQLiteOpenHelper {

    private	static final int DATABASE_VERSION =	1;
    private static final String DATABASE_NAME = "stressdatabase";
    private static final String TABLE_PRIMARY = "primarytable";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_STRESS_LVL = "stresslevel";
    private static final String COLUMN_SOURCES = "sources";
    private static final String COLUMN_SYMPTOMS = "symptoms";
    private static final String COLUMN_NOTES = "notes";

    public DBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }


    @Override
    public void	onCreate(SQLiteDatabase	db)	{
        String CREATE_PRIMARY_TABLE =
                "CREATE TABLE " + TABLE_PRIMARY + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY, "
                + COLUMN_DATE + " TEXT, "
                + COLUMN_STRESS_LVL + " INTEGER, "
                + COLUMN_SOURCES + " TEXT, "
                + COLUMN_SYMPTOMS + " TEXT, "
                + COLUMN_NOTES + " TEXT)";


        db.execSQL(CREATE_PRIMARY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRIMARY);
        onCreate(db);
    }

    public void addEntry(Data data) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, data.getEntryNumber());
        values.put(COLUMN_DATE, data.getDate());
        values.put(COLUMN_STRESS_LVL, data.getStressLevel());
        values.put(COLUMN_SOURCES, data.getSources());
        values.put(COLUMN_SYMPTOMS, data.getSymptoms());
        values.put(COLUMN_NOTES, data.getNotes());

        SQLiteDatabase db = this.getWritableDatabase();

        db.insert(TABLE_PRIMARY, null, values);
        db.close();

    }

    public Data findEntry(int entry_id) {
        //TODO implement this function
        String query = "Select * FROM " + TABLE_PRIMARY
                    + " WHERE " + COLUMN_ID + " = \"" + entry_id + "\"";
                    //not sure if these quotes are correct

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        Data data = new Data();
        if (cursor.moveToFirst()) {

            cursor.moveToFirst();
            data.setEntryNumber(Integer.parseInt(cursor.getString(0)));
            data.setDate(cursor.getString(1));
            data.setStressLevel(Integer.parseInt(cursor.getString(2)));
            data.setSources(cursor.getString(3));
            data.setSymptoms(cursor.getString(4));
            data.setNotes(cursor.getString(5));
            cursor.close();
        }
        else {
            data = null;
        }
        db.close();
        return data;
    }

}

