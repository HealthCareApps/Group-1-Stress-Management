package org.example.stress;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import android.view.View.OnClickListener;


/**
 * Demo application to show how to use the 
 * built-in SQLite database with a cursor to populate
 * a ListView.
 */
public class Journal extends Activity implements OnClickListener {
	
	DBAdapter myDb;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.journal_layout);

		final View toSelfCareButton = findViewById(R.id.button_selfcareplan); //link to the layout file
		toSelfCareButton.setOnClickListener(this); //<--enable the button

		openDB();
		if (((Data)this.getApplication()).isNewEntry())
		{
			addNewestRow();
		}
		populateListViewFromDB();
		//registerListClickCallback();
	}
	@Override
	protected void onDestroy() {
		super.onDestroy();	
		closeDB();
	}

	private void openDB() {
		myDb = new DBAdapter(this);
		myDb.open();
	}
	private void closeDB() {
		myDb.close();
	}

	/* 
	 * UI Button Callbacks
	 */
	public void onClick_AddRecord(View v) {


		// Add it to the DB and re-draw the ListView
		myDb.insertRow("Family, Work", 15, "Muscle aches", "Here are some notes.", "2016-03-27");
		myDb.insertRow("Work", 22, "Insomnia", "Some more notes.", "2016-03-04");
		myDb.insertRow("Unknown", 37, "Muscle aches, headache", "Even more notes!", "2016-04-10");
		myDb.insertRow("Work", 14, "Irritability", "Notes go here.", "2016-04-17");
		myDb.insertRow("Family", 26, "Fatigue", "Additional notes.", "2016-04-28");

		//String name, int studentNum, String favColour
		populateListViewFromDB();
	}

	public void onClick_ClearAll(View v) {
		myDb.deleteAll();
		populateListViewFromDB();
	}


	private void populateListViewFromDB() {
		Cursor cursor = myDb.getAllRows();
		
		// Allow activity to manage lifetime of the cursor.
		// DEPRECATED! Runs on the UI thread, OK for small/short queries.
		startManagingCursor(cursor);
		
		// Setup mapping from cursor to view fields:
		String[] fromFieldNames = new String[]
				{DBAdapter.KEY_SOURCES, DBAdapter.KEY_SYMPTOMS, DBAdapter.KEY_STRESS, DBAdapter.KEY_DATE, DBAdapter.KEY_NOTES};
		int[] toViewIDs = new int[]
				{R.id.item_sources,     R.id.item_symptoms,     R.id.item_stress,   R.id.item_date,    R.id.item_notes};
		
		// Create adapter to may columns of the DB onto elements in the UI.
		SimpleCursorAdapter myCursorAdapter =
				new SimpleCursorAdapter(
						this,					// Context
						R.layout.entry_layout,	// Row layout template
						cursor,					// cursor (set of DB records to map)
						fromFieldNames,			// DB Column names
						toViewIDs				// View IDs to put information in
						);
		
		// Set the adapter for the list view
		ListView myList = (ListView) findViewById(R.id.listViewFromDB);
		myList.setAdapter(myCursorAdapter);
	}
	
	private void registerListClickCallback() {
		ListView myList = (ListView) findViewById(R.id.listViewFromDB);
		myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View viewClicked,
									int position, long idInDB) {

				//updateItemForId(idInDB);
				//displayToastForId(idInDB);
			}
		});
	}
	
	private void updateItemForId(long idInDB) {
		Cursor cursor = myDb.getRow(idInDB);
		if (cursor.moveToFirst()) {
			long idDB = cursor.getLong(DBAdapter.COL_ROWID);
			String sources = cursor.getString(DBAdapter.COL_SOURCES);
			int stress = cursor.getInt(DBAdapter.COL_STRESS);
			String symptoms = cursor.getString(DBAdapter.COL_SYMPTOMS);
			String notes = cursor.getString(DBAdapter.COL_NOTES);
			String date = cursor.getString(DBAdapter.COL_DATE);

			//favColour += "!";
			myDb.updateRow(idInDB, sources, stress, symptoms, notes, date);
		}
		cursor.close();
		populateListViewFromDB();		
	}
	
	private void displayToastForId(long idInDB) {
		Cursor cursor = myDb.getRow(idInDB);
		if (cursor.moveToFirst()) {
			long idDB = cursor.getLong(DBAdapter.COL_ROWID);
			String sources = cursor.getString(DBAdapter.COL_SOURCES);
			int stress = cursor.getInt(DBAdapter.COL_STRESS);
			String symptoms = cursor.getString(DBAdapter.COL_SYMPTOMS);
			String notes = cursor.getString(DBAdapter.COL_NOTES);
			String date = cursor.getString(DBAdapter.COL_DATE);
			
			String message = "ID: " + idDB + "\n"
					+ "Date: " + date + "\n"
					+ "Stress score: " + stress + "\n"
					+ "Sources: " + sources + "\n"
					+ "Symptoms: " + symptoms + "\n"
					+ "Notes: " + notes + "\n";
			Toast.makeText(Journal.this, message, Toast.LENGTH_LONG).show();
		}
		cursor.close();
	}

	private void addNewestRow() {
		String date = ((Data)this.getApplication()).getDate();
		String sources = ((Data)this.getApplication()).getSources();
		String symptoms = ((Data)this.getApplication()).getSymptoms();
		String notes = ((Data)this.getApplication()).getNotes();
		int stress = ((Data)this.getApplication()).getStressLevel();

		myDb.insertRow(sources, stress, symptoms, notes, date);

		((Data) this.getApplication()).toggleNewEntryFlag(); //set flag back to false so that entry isnt re-added if user enters journal directly

		((Data)this.getApplication()).setDate("");
		((Data)this.getApplication()).setSources("");
		((Data)this.getApplication()).setSymptoms("");
		((Data)this.getApplication()).setNotes("");
		((Data)this.getApplication()).setStressLevel(0);

	}

	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.button_selfcareplan:
				((Data)this.getApplication()).setStressLevel(0);
				Intent i1 = new Intent(this, SelfCarePlan.class); //intent object is android code, passes control between classes
				startActivity(i1); //Each activity must be activated by the intent object
				finish();
				break;


		}
	}
}










